﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication2
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           SqlConnection con = new SqlConnection("Data Source= CHICPC02\\MSSQLSERVER2016; Initial Catalog= emp; Integrated Security=SSPI;");
           SqlCommand cmd = new SqlCommand(@"UPDATE [dbo].[emp1]
   SET [name] = '" + TextBox1.Text + "',[agr] = '" + TextBox2.Text + "',[emp_no] = '" + TextBox3.Text + "',[dept] ='" + TextBox4.Text + "'WHERE [name] = '" + TextBox1.Text + "' ", con);
           con.Open();
           cmd.ExecuteNonQuery();
           Response.Redirect("Default.aspx");
           con.Close();
 
        
        }
    }
}
