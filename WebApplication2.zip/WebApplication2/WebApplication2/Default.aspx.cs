﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication2
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source= CHICPC02\\MSSQLSERVER2016; Initial Catalog= emp; Integrated Security=SSPI;");
            SqlDataAdapter sda = new SqlDataAdapter(@"SELECT [id],[name]
        ,[agr]
        ,[emp_no]
        ,[dept]
        FROM [dbo].[emp1]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            Repeater1.DataSource = dt;
            Repeater1.DataBind();

        }


        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source= CHICPC02\\MSSQLSERVER2016; Initial Catalog= emp; Integrated Security=SSPI;");
            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[emp1]
           ([name]
           ,[agr]
           ,[emp_no]
           ,[dept])
     VALUES
           ('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            Response.Redirect("Default.aspx");
            con.Close();
            Decimal size = 0;
            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                lblmsg.Text = "Please enter your name !!";
                TextBox1.Focus();
                return false;
            }
            else if (!string.IsNullOrEmpty(TextBox2.Text) & !Regex.IsMatch(TextBox2.Text, "^[0-2]+$"))
            {
                lblmsg.Text = "Please enter only digits in Age !!";
                TextBox2.Focus();
                return false;
            }
            else if (!string.IsNullOrEmpty(TextBox3.Text) & !Regex.IsMatch(TextBox3.Text, "^[0-3]+$"))
            {
                lblmsg.Text = "Please enter only digits in Age !!";
                TextBox3.Focus();
                return false;
            }
            else if (string.IsNullOrEmpty(TextBox4.Text))
            {
                lblmsg.Text = "Please enter your name !!";
                TextBox4.Focus();
                return false;
            }

        }

        protected void Repeater1_ItemCommand(object sender, EventArgs e)
        {

        }


          

       



       

    }
}